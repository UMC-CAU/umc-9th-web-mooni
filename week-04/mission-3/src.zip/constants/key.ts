export const LOCAL_STORAGE_KEY = {
  accessToken: "accessToken",
};
