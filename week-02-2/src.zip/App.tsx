import "./App.css";
import ContextPage from "./ContextPage";

export default function App() {
  return (
    <>
      <ContextPage />
    </>
  );
}
